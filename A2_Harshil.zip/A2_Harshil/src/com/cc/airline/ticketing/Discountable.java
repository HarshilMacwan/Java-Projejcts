package com.cc.airline.ticketing;

public interface Discountable {
	double disountPrice(double price);
}

import java.util.*;

public class Employee {
	private String name;
	private String Address;
	private Date birthDate;
	private Date hireDate;
	private int salary;
	public Employee(String name,String address,Date birthDate,Date hireDate,int salary)
	{
		this.name=name;
		this.Address=address;
		this.birthDate=birthDate;
		this.hireDate= hireDate;
		this.salary=salary;
		
	}

}

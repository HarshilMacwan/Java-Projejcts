import java.text.*;
import java.util.*;

public class lab2 {

	public static void main(String[] args) {
		Scanner x =new Scanner(System.in);
		
		System.out.println("Please Enter the Name Of New Employee: ");
		String name= x.nextLine();
		System.out.println("Please Enter the New Employees Address: ");
		String address= x.nextLine();
		System.out.println("Please Enter the New Employees Date of Birth(MM/dd/yyyy):");
		String dob=x.nextLine();
		System.out.println("You Entered "+dob );
		System.out.print("Enter the date That the employee is Hired(MM/dd/yyyy)");
		String doh=x.nextLine();
		System.out.print("Please enter the salary of new employee");
		int salary =x.nextInt();
		SimpleDateFormat formatter1=new SimpleDateFormat("dd/MM/yyyy");
		Date dateOfBirth=formatter1.parse(dob);
		Date dateOfHiring=formatter1.parse(doh);
		Employee employee =new Employee(name,address,dateOfBirth,dateOfHiring,salary);
		
		
	
	}
}

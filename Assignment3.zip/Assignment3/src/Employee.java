// this is  base class employee

public  class Employee {
	private  String Name;
	private Double Salary;
	//public abstract void Employee();
	
	public Employee(String name,Double salary) {
		this.Name= name;
		this .Salary= salary;
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name=name;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		this.Salary= salary;
	}
	
	@Override
	public String toString() {
		return("\n Name of the employee is "+Name+"\n Salary of the "+Name+" is "+Salary);
	}
	

}

//This is driver class 
public class EmployeeTest 
{

	public static void main(String[] args) {
		Employee myEmployee = new Employee("Harshil",2000.0);
        System.out.print(myEmployee);
		Manager myManager= new Manager("Fillip",50000.0,"Accounting Department");
		System.out.println(myManager);
		Executive myExecutive =new Executive("Adrian",60000.0,"Fianance Department",5000.0);
		System.out.println(myExecutive);

	}

}

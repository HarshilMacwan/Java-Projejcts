//this class inherits from manager class
public class Executive extends Manager {
	private Double YearlyBonus;
	public Executive(String name,Double salary,String depart,Double yearlyBonus) {
		super(name,salary,depart);
		this.setYearlyBonus(yearlyBonus);
	}
	public Double getYearlyBonus() {
		return YearlyBonus;
	}
	public void setYearlyBonus(Double yearlyBonus) {
		YearlyBonus = yearlyBonus;
	}
	@Override
	public String toString()
	{
		return("\n Name of the Executive is "+super.getName()+
				"\n Salary of the "+super.getName()+"is"+super.getSalary()+"\n The Executive is boss of "
				+super.getDepart()+"\n Yearly bonus of the employee is "+YearlyBonus);
	}
}

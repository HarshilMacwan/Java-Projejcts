//this is manager class which in herits from employee class
public class Manager extends Employee {
	private String Depart;


	public Manager(String name, Double salary, String depart) {
		super(name,salary);
		this.Depart=depart;
		
	}
	/*public Manager(String name,Double salary) {
		super(name,salary);
		
	}*/
	
	
	public String getDepart() {
		return Depart;
	}

	public void setDepart(String depart) {
		this.Depart = depart;
	}
	@Override
	public String toString()
	{
		return("\n Name of the Manager is "+super.getName()+
				"\n Salary of the "+super.getName()+" is "+super.getSalary()+"\n This Manager manages "+Depart);
	}

}

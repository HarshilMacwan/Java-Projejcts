package Assignment4;

public class Division implements Runnable
{
	private int A;
	private int B;
	
	Division(int a,int b)
	{
		this.A=a;
		this.B=b;
	}
	public void Start() 
	{
		try 
		{
			
		System.out.println("The result division operation on "+A+" and "+B+" is "+(A/B));
		}
		catch(ArithmeticException e)
		{
			System.out.println("Can not devide a number by zero");
		}
		
	
	}
	public void run()
	{
		
	try 
	{
		Thread.sleep(1000);
	}
	catch (InterruptedException e) 
	{
		
		System.out.println("Addition thread Interrupted");;
	}
	
	}

}

package Assignment4;
import java.util.*;
public class MacLab4 {

	public static void main(String[] args)
	{
		String c="";
		do {
		Scanner x = new Scanner(System.in);
		System.out.println("Please enter the first intager");
		int Int1 =x.nextInt();
		System.out.println("Please enter the second intager");
		int Int2= x.nextInt();
		
		Addition A1=new Addition(Int1,Int2);
		A1.Start();
		Substraction S1= new Substraction(Int1,Int2);
		S1.Start();
		Multiplication M1= new Multiplication(Int1,Int2);
		M1.Start();
		Division D1= new Division(Int1,Int2);
		D1.Start();
		
		System.out.println("Do you wish to exit the calculator? (Y/N)");
		c=x.nextLine();
		}while(c.equalsIgnoreCase("Y"));
		
		
	}
	

}

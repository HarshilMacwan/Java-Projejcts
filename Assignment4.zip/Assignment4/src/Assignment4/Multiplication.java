package Assignment4;

public class Multiplication implements Runnable
{
	private int A;
	private int B;
	
	Multiplication(int a,int b)
	{
		this.A=a;
		this.B=b;
	}
	public void Start()
	{
		System.out.println("The result of Multiplication operation on "+A+" and "+B+" is "+(A*B));
	}
	public void run()
	{
		
	try 
	{
		Thread.sleep(1000);
	}
	catch (InterruptedException e) 
	{
		
		System.out.println("Multiplication thread Interrupted");;
	}
	
	}

}

package application;
	
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javax.swing.JOptionPane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage)
	{
		 
GridPane grid = new GridPane();
        
        grid.setHgap(10);
        grid.setVgap(20);
        grid.setPadding(new Insets(15,15,15,15));
		grid.setAlignment(Pos.CENTER);
		
		Label investmentAmountLb= new Label("Investment Amount: ");
		TextField investmentAmountTf= new TextField();
		Label intrestRateLb= new Label("Intrest Rate: ");
		TextField intrestRateTf= new TextField();
		Label noOfYearsLb= new Label("No of Years: ");
		TextField noOfYearsTf= new TextField();
		Label ResultLb= new Label("Result: ");
		TextField ResultTf= new TextField();
		ResultTf.setDisable(true);
		Button submitBt = new Button("Submit");
		Button resetBt = new Button("Reset");
		grid.add(investmentAmountLb, 0, 0);
		grid.add(investmentAmountTf, 1, 0);
		grid.add(intrestRateLb, 0, 1);
		grid.add(intrestRateTf, 1, 1);
		grid.add(noOfYearsLb, 0, 2);
		grid.add(noOfYearsTf, 1, 2);
		grid.add(ResultLb, 0, 3);
		grid.add(ResultTf, 1, 3);
		grid.add(resetBt,0,4 );
		grid.add(submitBt,1,4 );
		
        submitBt.setOnAction(e -> {
        	try {
            double amount= Double.parseDouble(investmentAmountTf.getText());
            double noOfYears= Double.parseDouble(noOfYearsTf.getText());
            double intrestRate= Double.parseDouble(intrestRateTf.getText());
            double result = amount*(1.0+((intrestRate*noOfYears)/100));
            ResultTf.setText(String.format("%.2f", result));
        	}
        	catch(Exception ex)
        	{
        		JOptionPane.showMessageDialog(null,"Invalid Value Inserted");
        	}
        	});
        resetBt.setOnAction(e ->{
        	investmentAmountTf.clear();
        	intrestRateTf.clear();
        	noOfYearsTf.clear();
        	ResultTf.clear();
        });


		
		Scene scene = new Scene(grid);
		primaryStage.setTitle("Event Handling Example");
		primaryStage.setScene(scene);
		primaryStage.show();
	
	}
	public static void main(String[] args)
	{
		Application.launch(args);

	}

}

package application;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;


public class Main extends Application
{

	private PreparedStatement preparedStatement;
	private TextField tfSIN = new TextField();
	private Label lblStatus = new Label();
	private Button btEdit = new Button(" Edit ");
	private Button btDelete = new Button(" Delete ");
	private TextField tfNewGrade = new TextField();
	
	
	@Override
	public void start(Stage primaryStage)
	{
		//initialize database connection and create a statement object
		initializeDB();
		
		Button btShowGrade = new Button(" Show Grade");
		HBox hBox = new HBox(10);
		hBox.setStyle("-fx-margin:20,10,10,10; -fx-padding:10,10,10,10;-fx-background-color:WHITE; -fx-border-radius:10;-fx-padding:5; -fx-background-radius:10");
		hBox.getChildren().addAll(new Label(" SIN"), tfSIN, (btShowGrade));
		btShowGrade.setStyle("-fx-font: 16 Verdana; -fx-base: #cccc00;-fx-border-radius:10;-fx-padding:5,5,5,5; -fx-background-radius:10;");
		tfSIN.setStyle("-fx-font: 14 Verdana; -fx-base: #cccc00;-fx-border-radius:10;-fx-padding:5,5,5,5; -fx-background-radius:10");
		tfSIN.setPrefWidth(200);
		VBox vBox = new VBox(10);
		btShowGrade.setMouseTransparent(false);
		vBox.setStyle("-fx-margin:20,10,10,10; -fx-padding:10,10,10,10;-fx-background-color:#ffff99;-fx-border-radius:10;-fx-padding:5; -fx-background-radius:10;");
		btEdit.setStyle("-fx-font: 16 Verdana; -fx-base: #cccc00;-fx-border-radius:10;-fx-padding:5,5,5,5; -fx-background-radius:10;");
		btDelete.setStyle("-fx-font: 16 Verdana; -fx-base: #cccc00;-fx-border-radius:10;-fx-padding:5,5,5,5; -fx-background-radius:10;");
		HBox hBox2 = new HBox(10);
		hBox2.setStyle("-fx-margin:20,10,10,10; -fx-padding:10,10,10,10;-fx-background-color:#ffff99; -fx-border-radius:10;-fx-padding:5; -fx-background-radius:10");
		btEdit.setVisible(false);
		btDelete.setVisible(false);
		hBox2.getChildren().addAll(btEdit,btDelete);
	
		tfNewGrade.setStyle("-fx-font: 14 Verdana; -fx-base: #cccc00;-fx-border-radius:10;-fx-padding:5,5,5,5; -fx-background-radius:10");
		tfNewGrade.setPrefWidth(200);
		tfNewGrade.setVisible(false);
		Label lblGrade = new Label("Enter New Grade");
	    Button btSubmit = new Button("Update Grade");
	    btSubmit.setVisible(false);
		lblGrade.setVisible(false);
		HBox hBox3 = new HBox(lblGrade,tfNewGrade,btSubmit);
	
		vBox.getChildren().addAll(hBox, lblStatus,hBox2,hBox3);
		
		lblStatus.setStyle("-fx-font: 18 Verdana;");
		tfSIN.setPrefColumnCount(5);
				
		//Register handler
		btShowGrade.setOnAction(e -> showGrade());
		
		//routine for UI
		Scene scene = new Scene(vBox, 420, 300);
		primaryStage.setTitle("FindGrade");
		primaryStage.setScene(scene);
		primaryStage.show();	
		
		btEdit.setOnAction((
				e ->
				{
					lblGrade.setVisible(true);
					tfNewGrade.setVisible(true);
					btSubmit.setVisible(true);
				String queryString= "UPDATE Student1 SET grade = ? WHERE sin = ?";
				String sin = tfSIN.getText();
				String grade = tfNewGrade.getText();
				try 
				{
					preparedStatement.setString(1, queryString);
				}
				catch (SQLException e1) 
				
				{
					
					e1.printStackTrace();
				}
				
		     	}
				));
		
	}
	
	private void initializeDB()
	{
		try
		{
			//load jdbc driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//for sqlserver
			//Class.forName(com.mysql.jdbc.Driver");
			System.out.println("Driver loaded.");
			
			//establish a connection
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@oracle1.centennialcollege.ca:1521:SQLD","COMP228_F19_sy_46", "password");
			System.out.println("Database connected.");
			String queryString = "select firstName, mi, lastName, grade from Student1 where sin = ?";
			
			
			//create a statement
			preparedStatement = connection.prepareStatement(queryString);
			
		}
		catch(Exception ex)
		{
			
			ex.printStackTrace();
			
		}		
		
	}
	
	private void showGrade()
	{
		String sin = tfSIN.getText();
		try
		{
			preparedStatement.setString(1, sin);
			ResultSet rset = preparedStatement.executeQuery();
			
			if(rset.next())
			{
				String lastName = rset.getNString(1);
				String mi = rset.getString(2);
				String firstName = rset.getString(3);
				String grade = rset.getString(4);
				
				//display result in a label
				lblStatus.setText(firstName + " " + mi + " " + lastName + "'s grade is " + grade);
				btEdit.setVisible(true);
				btDelete.setVisible(true);
				
			}
			else
			{
				lblStatus.setText("Not found.");
				
			}	
			
		}
		
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		
	}
	public static void main(String[] args)
	{
		Application.launch();
		
	}
	
}

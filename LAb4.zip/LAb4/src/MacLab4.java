
public class MacLab4
{

	public static void main(String[] args) 
	{
		Runable R1= new Runable("Thread-1");
        R1.start();
        
        Runable R2 = new Runable("Thread-2");
        R2.start();




	}

}
